"""
Backtest / Stress Test v2
Runs enhanced Heikin Ashi strategy on historical XAU/USD data.
Includes: EMA filter, 3rd candle confirmation, trailing SL, time filter.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from heikin_ashi import convert_to_heikin_ashi, calculate_ema
from strategy import detect_buy_signal, detect_sell_signal, is_trading_hours_for_time


def calculate_trailing_sl_backtest(direction, entry_price, current_price, lots, contract_size=100):
    """
    Backtest version of trailing SL based on actual dollar profit.
    Simulates what broker.calculate_sl_from_running_profit does.
    """
    # Calculate actual profit in dollars
    if direction == "BUY":
        profit = (current_price - entry_price) * lots * contract_size
    else:
        profit = (entry_price - current_price) * lots * contract_size

    if profit < config.TRAIL_ACTIVATION_PROFIT:
        # Not activated yet, keep initial SL
        ppd = 1.0 / (lots * contract_size)
        if direction == "BUY":
            return entry_price - (config.MAX_LOSS_DOLLARS * ppd), profit
        else:
            return entry_price + (config.MAX_LOSS_DOLLARS * ppd), profit

    # Trail: lock (profit - trail_distance) dollars
    locked = profit - config.TRAIL_DISTANCE_PROFIT
    ppd = 1.0 / (lots * contract_size)

    if direction == "BUY":
        return entry_price + (locked * ppd), profit
    else:
        return entry_price - (locked * ppd), profit


def run_backtest(candles, timeframe_label):
    ha_candles = convert_to_heikin_ashi(candles)

    trades = []
    in_trade = False
    trade = None
    initial_balance = 100000.0
    balance = initial_balance
    peak_balance = initial_balance
    max_drawdown = 0

    for i in range(3, len(ha_candles)):
        window_ha = ha_candles[:i + 1]
        window_raw = candles[:i + 1]
        latest_raw = candles[i]
        current_price = latest_raw["close"]

        # --- MANAGE OPEN TRADE ---
        if in_trade:
            # Calculate trailing SL based on actual dollar profit
            new_sl, actual_profit = calculate_trailing_sl_backtest(
                trade["direction"], trade["entry_price"], current_price,
                trade["lots"], trade["contract_size"]
            )
            if trade["direction"] == "BUY":
                if new_sl > trade["current_sl"]:
                    trade["current_sl"] = new_sl
            elif trade["direction"] == "SELL":
                if new_sl < trade["current_sl"]:
                    trade["current_sl"] = new_sl

            # Check SL hit
            sl_hit = False
            if trade["direction"] == "BUY" and latest_raw["low"] <= trade["current_sl"]:
                trade["exit_price"] = trade["current_sl"]
                trade["exit_reason"] = "STOP LOSS"
                sl_hit = True
            elif trade["direction"] == "SELL" and latest_raw["high"] >= trade["current_sl"]:
                trade["exit_price"] = trade["current_sl"]
                trade["exit_reason"] = "STOP LOSS"
                sl_hit = True

            if sl_hit:
                trade["exit_time"] = ha_candles[i]["time"]
                # Calculate actual P&L in dollars
                if trade["direction"] == "BUY":
                    pnl = (trade["exit_price"] - trade["entry_price"]) * trade["lots"] * trade["contract_size"]
                else:
                    pnl = (trade["entry_price"] - trade["exit_price"]) * trade["lots"] * trade["contract_size"]

                # Determine exit type
                if trade["direction"] == "BUY" and trade["current_sl"] > trade["entry_price"]:
                    locked = (trade["current_sl"] - trade["entry_price"]) * trade["lots"] * trade["contract_size"]
                    trade["exit_reason"] = f"TRAILING SL (locked ${locked:.2f})"
                elif trade["direction"] == "SELL" and trade["current_sl"] < trade["entry_price"]:
                    locked = (trade["entry_price"] - trade["current_sl"]) * trade["lots"] * trade["contract_size"]
                    trade["exit_reason"] = f"TRAILING SL (locked ${locked:.2f})"
                elif abs(trade["current_sl"] - trade["entry_price"]) < 0.01:
                    trade["exit_reason"] = "BREAKEVEN SL"

                trade["pnl"] = round(pnl, 2)
                balance += pnl
                trade["balance_after"] = round(balance, 2)
                trades.append(trade)
                in_trade = False
                trade = None

                if balance > peak_balance:
                    peak_balance = balance
                dd = (peak_balance - balance) / peak_balance * 100
                if dd > max_drawdown:
                    max_drawdown = dd
                continue

            continue  # Still in trade, skip entry check

        # --- CHECK ENTRY ---
        if not in_trade:
            contract_size = 100  # XAUUSD: 1 lot = 100 oz

            # BUY
            buy_signal, entry_price, _ = detect_buy_signal(window_ha, window_raw)
            if buy_signal:
                trade_amount = balance * config.POSITION_SIZE_PCT
                lots = trade_amount / (entry_price * contract_size)
                lots = max(0.01, round(int(lots / 0.01) * 0.01, 2))
                # Calculate SL for max $2 loss
                ppd = 1.0 / (lots * contract_size)
                sl = entry_price - (config.MAX_LOSS_DOLLARS * ppd)
                trade = {
                    "direction": "BUY",
                    "entry_price": entry_price,
                    "current_sl": sl,
                    "lots": lots,
                    "contract_size": contract_size,
                    "entry_time": ha_candles[i]["time"],
                }
                in_trade = True
                continue

            # SELL
            sell_signal, entry_price, _ = detect_sell_signal(window_ha, window_raw)
            if sell_signal:
                trade_amount = balance * config.POSITION_SIZE_PCT
                lots = trade_amount / (entry_price * contract_size)
                lots = max(0.01, round(int(lots / 0.01) * 0.01, 2))
                ppd = 1.0 / (lots * contract_size)
                sl = entry_price + (config.MAX_LOSS_DOLLARS * ppd)
                trade = {
                    "direction": "SELL",
                    "entry_price": entry_price,
                    "current_sl": sl,
                    "lots": lots,
                    "contract_size": contract_size,
                    "entry_time": ha_candles[i]["time"],
                }
                in_trade = True

    # --- REPORT ---
    print(f"\n{'=' * 65}")
    print(f"  BACKTEST v2 — {timeframe_label}")
    print(f"{'=' * 65}")
    print(f"  Enhancements: EMA-{config.EMA_PERIOD} filter | 3rd candle confirm | Trailing SL | Time filter")
    print(f"  Period:          {ha_candles[0]['time'][:10]} to {ha_candles[-1]['time'][:10]}")
    print(f"  Total candles:   {len(ha_candles)}")
    print(f"  Total trades:    {len(trades)}")

    if trades:
        wins = [t for t in trades if t["pnl"] > 0]
        losses = [t for t in trades if t["pnl"] <= 0]
        breakevens = [t for t in trades if t["pnl"] == 0]
        total_pnl = sum(t["pnl"] for t in trades)
        avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t["pnl"] for t in losses) / len(losses) if losses else 0

        # Count exit types
        sl_exits = len([t for t in trades if "STOP LOSS" in t["exit_reason"]])
        trail_exits = len([t for t in trades if "TRAILING" in t["exit_reason"]])
        be_exits = len([t for t in trades if "BREAKEVEN" in t["exit_reason"]])

        print(f"  Wins:            {len(wins)}")
        print(f"  Losses:          {len(losses)}")
        print(f"  Breakeven:       {len(breakevens)}")
        print(f"  Win rate:        {len(wins) / len(trades) * 100:.1f}%")
        print(f"  Avg win:         ${avg_win:,.2f}")
        print(f"  Avg loss:        ${avg_loss:,.2f}")
        print(f"  Total P&L:       ${total_pnl:,.2f}")
        print(f"  Final balance:   ${balance:,.2f}")
        print(f"  Return:          {(balance - initial_balance) / initial_balance * 100:.2f}%")
        print(f"  Max drawdown:    {max_drawdown:.2f}%")
        print(f"  Exit types:      SL: {sl_exits} | Trailing: {trail_exits} | Breakeven: {be_exits}")

        # Risk/Reward ratio
        if avg_loss != 0:
            rr = abs(avg_win / avg_loss)
            print(f"  Risk/Reward:     1:{rr:.2f}")

        # Show trades
        print(f"\n  {'─' * 61}")
        print(f"  {'#':>3} {'Dir':<5} {'Entry':>10} {'Exit':>10} {'P&L':>10} {'Reason'}")
        print(f"  {'─' * 61}")
        for i, t in enumerate(trades, 1):
            pnl_str = f"${t['pnl']:,.2f}"
            marker = "+" if t["pnl"] > 0 else " "
            print(f"  {i:>3} {t['direction']:<5} {t['entry_price']:>10.2f} {t['exit_price']:>10.2f} {marker}{pnl_str:>9} {t['exit_reason']}")
        print(f"  {'─' * 61}")
    else:
        print("  No trades found in this period.")

    print()
    return trades, balance


def generate_sample_data():
    """Generate realistic XAU/USD-like price data for testing."""
    import random
    random.seed(42)

    candles = []
    price = 2300.00

    for i in range(5000):
        hour = (i % 1440) // 60  # hour of day in UTC

        # More volatility during London/NY sessions
        if 8 <= hour < 20:
            volatility = 0.7
        else:
            volatility = 0.3

        # Add some trending behavior
        trend = 0.01 if i % 500 < 250 else -0.01
        change = random.gauss(trend, volatility)

        open_p = price
        close_p = open_p + change
        high_p = max(open_p, close_p) + abs(random.gauss(0, volatility * 0.5))
        low_p = min(open_p, close_p) - abs(random.gauss(0, volatility * 0.5))

        candles.append({
            "time": f"2026-04-{7 + i // 1440:02d}T{hour:02d}:{i % 60:02d}:00Z",
            "open": round(open_p, 2),
            "high": round(high_p, 2),
            "low": round(low_p, 2),
            "close": round(close_p, 2),
            "volume": random.randint(100, 1000),
        })
        price = close_p

    return candles


def main():
    print("\nXAU/USD Heikin Ashi Strategy v2 — Backtest")
    print("=" * 65)
    print("Enhancements: EMA filter | 3rd candle | Trailing SL | Time filter")

    use_live = False

    if config.OANDA_API_KEY if hasattr(config, 'OANDA_API_KEY') else False:
        pass  # OANDA removed, MT5 only

    if not use_live:
        print("\nUsing generated sample data (connect MT5 for real data)\n")
        sample_candles = generate_sample_data()

        run_backtest(sample_candles, "XAU/USD 1-Minute (Sample Data)")

        candles_3m = sample_candles[::3]
        run_backtest(candles_3m, "XAU/USD 3-Minute (Sample Data)")


if __name__ == "__main__":
    main()
